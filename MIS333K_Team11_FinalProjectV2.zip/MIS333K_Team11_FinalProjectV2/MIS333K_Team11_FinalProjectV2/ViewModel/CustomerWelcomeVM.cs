﻿using MIS333K_Team11_FinalProjectV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MIS333K_Team11_FinalProjectV2.ViewModels
{
    public class CustomerWelcomeVM
    {
        public string CustomerName { get; set; }

        public Movie FeaturedMovie { get; set; }
    }
}